import os
from capital_api.client import CapitalAPI, CapitalConfig
from dotenv import load_dotenv

def main():
    load_dotenv()  # liest .env falls vorhanden
    cfg = CapitalConfig(
        identifier=os.getenv("CAPITAL_IDENTIFIER","youremail@example.com"),
        api_key=os.getenv("CAPITAL_API_KEY","YOUR_API_KEY"),
        api_password=os.getenv("CAPITAL_API_PASSWORD","YOUR_API_KEY_PASSWORD"),
        use_demo=os.getenv("CAPITAL_USE_DEMO","true").lower()=="true"
    )
    api = CapitalAPI(cfg)

    print("[1] Login ...")
    api.login()
    print("   OK.")

    print("[2] Markets suchen: NVDA")
    markets = api.search_markets("NVDA")
    if not markets:
        print("   Keine Treffer."); return
    epic = markets[0].get("epic") or markets[0].get("symbol")
    print("   Epic:", epic)

    # Achtung: im Demo-Konto wird damit wirklich eine Order platziert!
    print("[3] Market-Position öffnen (BUY size=1) ...")
    deal_ref = api.create_position(epic=epic, direction="BUY", size=1)
    print("   dealReference:", deal_ref)

    print("[4] Confirm ...")
    conf = api.confirm(deal_ref)
    print("   Status:", conf.get("status"), "Deal:", conf.get("affectedDeals"))

if __name__ == "__main__":
    main()
